'user strict'

var express = require('express');
var empresaController = require('../controllers/empresa.controller');
var mdAuth = require('../middlewares/authenticated');

var api = express.Router();


// authenticated
api.post('/saveEmpresa/:id', [mdAuth.ensureAuth, mdAuth.ensureAuthAdmin], empresaController.saveEmpresa);
api.put('/:id/updateEmpresa/:idA', [mdAuth.ensureAuth, mdAuth.ensureAuthAdmin], empresaController.updateEmpresa);
api.delete('/:id/removeEmpresa/:idA',[mdAuth.ensureAuth, mdAuth.ensureAuthAdmin], empresaController.removeEmpresa);
api.get('/getEmpresas/:id', [mdAuth.ensureAuth, mdAuth.ensureAuthAdmin],empresaController.getEmpresas);
api.post('/search/:id',[mdAuth.ensureAuth, mdAuth.ensureAuthAdmin], empresaController.search);



api.post('/login', empresaController.login);
api.post('/createAdmin', empresaController.createAdmin);





module.exports = api;

