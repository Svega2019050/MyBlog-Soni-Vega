'user strict'

var express = require('express');
var empleadoController = require('../controllers/empleado.controller');
var mdAuth = require('../middlewares/authenticated');

var api = express.Router();


api.put('/setEmpleado/:id',mdAuth.ensureAuth,empleadoController.setEmpleado);
api.put('/:idEmpre/updateEmpleado/:idEmple',mdAuth.ensureAuth,empleadoController.updateEmpleado);
api.put('/:idEmpre/removeEmpleado/:idEmple',mdAuth.ensureAuth,empleadoController.removeEmpleado);
api.get('/:id/getEmpleados',mdAuth.ensureAuth,empleadoController.getEmpleados);
api.get('/:idEmpre/getEmpleado/:idEmple',mdAuth.ensureAuth,empleadoController.getEmpleado);
api.post('/:idEmpre/search',mdAuth.ensureAuth,empleadoController.search);
api.post('/:idEmpre/createPdf',mdAuth.ensureAuth,empleadoController.createPdf);



module.exports = api;

