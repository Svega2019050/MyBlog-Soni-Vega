'user strict'

var Empleado = require('../models/empleado.model');
var Empresa = require('../models/empresa.model');
var jwt = require('../services/jwt');
var PDFDocument = require('pdfkit');
var fs = require('fs');
var mongoose = require('mongoose');


function createPdf (req, res){
    let pdfDoc = new PDFDocument;
    let empresaId = req.params.idEmpre;

    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{
        Empresa.findById({_id: empresaId}).populate('empleado').exec((err, empresaFind)=>{
                if(err){
                    res.status(500).send({message: 'Error en el servidor al intentar buscar'})
                }else if(empresaFind){  
                    Empleado.find({}).exec((err, empleados)=>{                    
                        if(err){
                            res.status(500).send({message: 'Error general en el servidor'});
                        }else if(empleados){
                           

                            const cantidad = mongoose.model('empleado');
                            cantidad.estimatedDocumentCount((err, numOfDocs) => {
                              if(err) throw(err);

                                pdfDoc.pipe(fs.createWriteStream('Control de Empleados.pdf')).on('finish', function () {
                                    console.log('Archivo creado satisfactoriamente ....');
                                    return res.send({message: 'Se genero el PDF con Exito'});
                                    });

                                    pdfDoc
                                    .fillColor('blue')
                                    .font('Courier').fontSize(20).fillColor('black');
                                    pdfDoc.text('Control de Empleados');
                                    pdfDoc.text('\n' + "Nombre de la Empresa: " + empresaFind.name  ); 
                                    pdfDoc.text( '\n' + 'Cantidad de Empleados:' + ' ' + numOfDocs);
                                    pdfDoc.text('\n' + "Empleados: ");            
                                    pdfDoc.text('\n' + empleados , 200, 200);     

                                    pdfDoc.end();
                            });
                            
                        }else{
                            res.status(404).send({message: 'No hay Empleados'});
                        }
                    })
                }else{
                    res.status(200).send({message: 'Empresa Inexistente'})
                }
            })
    
        }  
};


// CRUD Empleado

//Guardar Empleado
function setEmpleado(req, res){
    var empresarId = req.params.id;
    var params = req.body;
    var empleado = new Empleado();

    if(empresarId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{
        Empresa.findById(empresarId, (err, empresaFind)=>{
            if(err){
                return res.status(500).send({message: 'Error general'})
            }else if(empresaFind){
                empleado.name = params.name.trim( );
                empleado.lastname = params.lastname.trim( );
                empleado.phone = params.phone.trim( );
                empleado.email = params.email.trim( );
                empleado.puesto = params.puesto.trim( );
                empleado.departamento = params.departamento.trim( );

                empleado.save((err, empleadoSaved)=>{
                    if(err){
                        return res.status(500).send({message: 'Error general al guardar'})
                    }else if(empleadoSaved){
                        Empresa.findByIdAndUpdate(empresarId, {$push:{empleado: empleadoSaved._id}}, {new: true}, (err, empleadoPush)=>{
                            if(err){
                                return res.status(500).send({message: 'Error general al agergar Empleado'})
                            }else if(empleadoPush){
                                return res.send({message: 'Empleado agregado', empleado});
                            }else{
                                return res.status(500).send({message: 'Error al agregar Empleado'})
                            }
                        })
                    }else{
                        return res.status(404).send({message: 'No se guardó el Empleado'})
                    }
                })
            }else{
                return res.status(404).send({message: 'El Empresa al que deseas agregar al empleado no existe.'})
            }
        })
    }
        
    
};

//Actualizar Empleado
function updateEmpleado(req, res){
    let empresaId = req.params.idEmpre;
    let empleadoId = req.params.idEmple;
    let update = req.body;

    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{
        if(update.name && update.lastname && update.phone && update.email && update.puesto && update.departamento ){
            Empleado.findById(empleadoId, (err, empleadiFind)=>{
                if(err){
                    return res.status(500).send({message: 'Error general al buscar'});
                }else if(empleadiFind){
                    Empresa.findOne({_id: empresaId, empleado: empleadoId}, (err, empresaFind)=>{
                        if(err){
                            return res.status(500).send({message: 'Error general en la busqueda de Empresa'});
                        }else if(empresaFind){
                            Empleado.findByIdAndUpdate(empleadoId, update, {new: true}, (err, empleadoUpdated)=>{
                                if(err){
                                    return res.status(500).send({message: 'Error general en la actualización'});
                                }else if(empleadoUpdated){
                                    return res.send({message: 'Empleado actualizado', empleadoUpdated});
                                }else{
                                    return res.status(404).send({message: 'Empleado no actualizado'});
                                }
                            })
                        }else{
                            return res.status(404).send({message: 'Empresa no encontrado'})
                        }
                    })
                }else{
                    return res.status(404).send({message: 'Empleado a actualizar inexistente'});
                }
            })
        }else{
            return res.status(404).send({message: 'Por favor ingresa los datos mínimos para actualizar'});
        }
    }     
};

//Eliminar Empleado
function removeEmpleado(req, res){
    let empresaId = req.params.idEmpre;
    let empleadoId = req.params.idEmple;

    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{
        Empresa.findOneAndUpdate({_id: empresaId, empleado: empleadoId},
            {$pull:{empleado: empleadoId}}, {new:true}, (err, empleadoPull)=>{
                if(err){
                    return res.status(500).send({message: 'Error general'});
                }else if(empleadoPull){
                    Empleado.findByIdAndRemove(empleadoId, (err, empleadoRemoved)=>{
                        if(err){
                            return res.status(500).send({message: 'Error general al eliminar Empleado'});
                        }else if(empleadoRemoved){      
                            return res.send({message: 'Empleado eliminado', empleadoRemoved});
                        }else{
                            return res.status(500).send({message: 'Empleado no encontrado, o ya eliminado'});
                        }
                    })
                }else{
                    return res.status(500).send({message: 'No se pudo eliminar el Empleado de la empresa'});
                }
        })
    } 
};

//Buscar Empleado


function getEmpleados(req, res){
    let empresaId = req.params.id;

    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{
        Empresa.findOne({_id: empresaId }).populate('empleado').exec((err, empresaFind)=>{
            if(err){
                res.status(500).send({message: 'Error en el servidor al intentar buscar'})
            }else if(empresaFind){  
                    Empleado.find({}).populate('empleado').exec((err, empleados)=>{                    
                        if(err){
                            res.status(500).send({message: 'Error general en el servidor'});
                        }else if(empleados){
    
                            const cantidad = mongoose.model('empleado');
                            cantidad.estimatedDocumentCount((err, cantidad) => {
                            if(err) throw(err);
                                res.send({message: 'Total de Empresas:',cantidad,empresaId, empleados});
                            }); 
                                                
                        }else{
                            res.status(404).send({message: 'No hay Empleados'});
                        }
                    })
            }else{
                res.status(200).send({message: 'Empresa Inexistente'})
            }
        })

    }
    
};


function search(req, res){
    var params = req.body;
    let empresaId = req.params.idEmpre;

    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{      
        Empresa.findOne({_id: empresaId}).populate('empleado').exec((err, empresaFind)=>{
            if(err){
                res.status(500).send({message: 'Error en el servidor al intentar buscar'})
            }else if(empresaFind){  
                Empleado.find({}).populate('empleado').exec((err, empleados)=>{                    
                    if(err){
                        res.status(500).send({message: 'Error general en el servidor'});
                    }else if(empleados){
                            if( params.search){
                                Empleado.find({$or:[
                                    {name: params.search.trim( )},
                                    {empleadoId: params.search.trim( )},
                                    {lastname: params.search.trim( )},
                                    {departamento: params.search.trim( )},
                                    {puesto: params.search.trim( )}]}, (err, resultSearch)=>{
                                        if(err){
                                            return res.status(500).send({message: 'Error general'});
                                        }else if(resultSearch){
                                            return res.send({message: 'Coincidencias encontradas: ', resultSearch});
                                        }else{
                                            return res.status(403).send({message: 'Búsqueda sin coincidencias'});
                                        }
                                    })
                            }else{
                                res.status(200).send({message: 'Porfavor ingrese valores'})
                            }
                                            
                    }else{
                        res.status(404).send({message: 'No hay Empleados'});
                    }
                })
            }else{
                res.status(200).send({message: 'Empresa Inexistente'})
            }
        })

    }
};

function getEmpleado(req,res){
    let empresaId = req.params.idEmpre;
    let empleadoId = req.params.idEmple;

    Empresa.findOne({_id: empresaId}, (err, empleadiFind)=>{
        if(err){
            return res.status(500).send({message: 'Error general al buscar'});
        }else if(empleadiFind){
            Empleado.findOne({_id: empleadoId}).exec((err, empresaFind)=>{
                if(err){
                    res.status(500).send({message: 'Error general en el servidor'});
                }else if(empresaFind){
                    res.status(200).send({message: 'Empleado: ', Empleado: empresaFind})
                }else{
                    res.status(404).send({message: 'Empleado no encontrado'});
                }
            })
        }else{
            return res.status(404).send({message: 'Empleado a actualizar inexistente'});
        }
    });
    
};



module.exports = {
    setEmpleado,
    updateEmpleado,
    removeEmpleado,
    getEmpleados,
    search,
    createPdf,
    getEmpleado
}



