'user strict'

var Empresa = require('../models/empresa.model');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../services/jwt');
var mongoose = require('mongoose');
var Empleado = require('../models/empleado.model');

function createAdmin(req,res){
    let empresa = new Empresa();
    let params = req.body;

    process.stdout.write(params.username = 'admin');

    params.username = 'admin'
    params.password = '12345'
    params.role = 'ROLE_ADMIN'

    Empresa.findOne({username: params.username},(err,AdminFind)=>{
        if(err){
            console.status(500).send({message: 'Error general', err})
        }else if(AdminFind){
            res.send({message: 'Rol ya utilizado'})
        }else{  
            bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                if(err){
                    return res.status(500).send({message: 'Error general en la encriptación'});
                }else if(passwordHash){
                    empresa.password = passwordHash;
                    empresa.username = params.username.toLowerCase();
                    empresa.role = params.role;

                    empresa.save((err, adminSaved)=>{
                        if(err){
                            res.status(500).send({message: 'Error al crear Rol'})
                            console.log('Error al crear el usuario');
                        }else if(adminSaved){
                            res.status(500).send({message: 'Rol administrador creado',adminSaved })
                            console.log('Rol administrador creado');
                        }else{
                            res.status(500).send({message: 'Rol administrador no creado'})
                            console.log('Rol administrador no creado');
                        }
                    })
                }else{
                    return res.status(401).send({message: 'Contraseña no encriptada'});
                }
            }) 
        }
    })   
};

function login (req, res){
    var params = req.body;
    
    if(params.username && params.password){
        Empresa.findOne({username: params.username.toLowerCase().trim( )}, (err, empresaFind)=>{
            if(err){
                return res.status(500).send({message: 'Error general'});
            }else if(empresaFind){
                bcrypt.compare(params.password  , empresaFind.password, (err, checkPassword)=>{
                    if(err){
                        return res.status(500).send({message: 'Error general en la verificación de la contraseña'});
                    }else if(checkPassword){
                        if(params.gettoken){
                            return res.send({ Token: jwt.createToken(empresaFind)});
                        }else{
                            return res.send({ message: 'Usuario logeado'});
                        }
                    }else{
                        return res.status(404).send({message: 'Contraseña incorrecta'});
                    }
                })
            }else{
                return res.send({message: 'Usuario no encontrado'});
            }
        })
    }else{
        return res.status(401).send({message: 'Por favor ingrese los datos obligatorios'});
    }

};


//Guardar Empresa
function saveEmpresa(req, res){
    var empresa = new Empresa();
    var params = req.body;
    let empresaId = req.params.id;

    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else {
        if(params.name && params.username && params.password && params.phone && params.email){
            Empresa.findOne({username: params.username.toLowerCase().trim( )}, (err, empresaFind)=>{
                if(err){
                    return res.status(500).send({message: 'Error general en el servidor'});
                }else if(empresaFind){
                    return res.send({message: 'Usuario de Empresa ya en uso'});
                }else{
                    bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                        if(err){
                            return res.status(500).send({message: 'Error general en la encriptación'});
                        }else if(passwordHash){
                            empresa.password = passwordHash;
                            empresa.name = params.name.trim( );                      
                            empresa.username = params.username.toLowerCase().trim( );
                            empresa.email = params.email.toLowerCase().trim( );
                            empresa.phone = params.phone.trim( );     
    
                            empresa.save((err, empresaSaved)=>{
                                if(err){
                                    return res.status(500).send({message: 'Error general al guardar'});
                                }else if(empresaSaved){
                                    return res.send({message: 'Empresa Guardada Exitosamente', empresaSaved});
                                }else{
                                    return res.status(500).send({message: 'No se Guardo la Empresa'});
                                }
                            })
                        }else{
                            return res.status(401).send({message: 'Contraseña no encriptada'});
                        }
                    })
                }
            })
        }else{
            return res.send({message: 'Por favor ingresa los datos obligatorios'});
        }
    }
    
};

// Actualizar Empresa
function updateEmpresa(req, res){
    let empresaId = req.params.id;
    let empresaId2 = req.params.idA;
    let update = req.body;

    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{
        if(update.password){
            return res.status(401).send({ message: 'No se puede actualizar la contraseña desde esta función'});
        }else{
            Empresa.findOne({_id: empresaId},(err, findAndmin)=>{
                if(err){
                    return res.status(500).send({ message: 'Error general'});
                }else if(findAndmin){
                    if(update.username){
                        Empresa.findOne({username: update.username.toLowerCase().trim( )}, (err, empresaFind)=>{
                            if(err){
                                return res.status(500).send({ message: 'Error general'});
                            }else if(empresaFind){
                                return res.send({message: 'No se puede actualizar, Nombre de usuario de la empresa ya en uso'});
                            }else{
                                Empresa.findByIdAndUpdate(empresaId2, update, {new: true}, (err, empresaUpdated)=>{
                                    if(err){
                                        return res.status(500).send({message: 'Error general al actualizar'});
                                    }else if(empresaUpdated){
                                        return res.send({message: 'Empresa actualizada', empresaUpdated});
                                    }else{
                                        return res.send({message: 'No se pudo actualizar al usuario de la Empresa'});
                                    }
                                })
                            }
                        })
                    }else{
                        Empresa.findByIdAndUpdate(empresaId2, update, {new: true}, (err, empresaUpdated)=>{
                            if(err){
                                return res.status(500).send({message: 'Error general al actualizar'});
                            }else if(empresaUpdated){
                                return res.send({message: 'Empresa actualizada', empresaUpdated});
                            }else{
                                return res.send({message: 'No se pudo actualizar al usuario de la Empresa'});
                            }
                        })
                    }
                }else{
                    return res.send({message: 'Empresa no encontrada '});
                }
            })          
        }     
    }  
};

// Eliminar Empresa 
function removeEmpresa(req, res){
    let empresaId = req.params.id;
    let empresaId2 = req.params.idA;

    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{
        Empresa.findOne({_id: empresaId},(err, findAndmin)=>{
            if(err){
                return res.status(500).send({ message: 'Error general'});
            }else if(findAndmin){
                Empresa.findByIdAndRemove(empresaId2,(err, empresaRemoved)=>{
                    if(err){
                        res.status(500).send({message: 'Error al intentar eliminar la Empresa'});
                    }else if(empresaRemoved){
                        
                        res.send({message: 'Empresa eliminado', empresaRemoved});
                    }else{
                        res.send({message: 'No existe la empresa, o ya fue eliminado'});
                    } 

                 })
            }else{
                return res.send({message: 'Empresa no encontrada '});
            }

        })
    }  
};

// Listar Empresas
function getEmpresas(req, res){
    var empresaId = req.params.id;
    var empresaSchema 


    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{
        Empresa.find({}).exec((err, empresas)=>{
            if(err){
                res.status(500).send({message: 'Error en el servidor al intentar buscar'})
            }else if(empresas){  

                const cantidad = mongoose.model('empresa', empresaSchema);
                cantidad.estimatedDocumentCount((err, cantidad) => {
                if(err) throw(err);
                 res.send({message: 'Total de Empresas:',cantidad, empresas})
                }); 
                
            }else{
                res.status(200).send({message: 'No hay Empresas'})
            }
        })
    }

};

function search(req, res){
    var params = req.body;
    let empresaId = req.params.id;

    if(empresaId != req.user.sub){
        return res.status(401).send({ message: 'No tienes permiso para realizar esta acción'});
    }else{
        if(params.search){
            Empresa.find({$or:[{name: params.search.trim( )},
                            {email: params.search.trim( )},
                            {username: params.search.trim( )}]}, (err, resultSearch)=>{
                                if(err){
                                    return res.status(500).send({message: 'Error general'});
                                }else if(resultSearch){
                                    return res.send({message: 'Coincidencias encontradas: ', resultSearch});
                                }else{
                                    return res.status(403).send({message: 'Búsqueda sin coincidencias'});
                                }
                            }).populate('empleado')
        }else{
            return res.status(403).send({message: 'Ingrese datos en el campo de búsqueda'});
        }
    }   
};



module.exports = {
    saveEmpresa,
    updateEmpresa,
    removeEmpresa,
    getEmpresas,
    search,
    login,
    createAdmin
}