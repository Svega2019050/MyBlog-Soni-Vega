'user strict'

const { json } = require('body-parser');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var empresaSchema = Schema ({
    name: String,
    username: String,
    password: String,
    phone: Number,
    email: String,
    role: String,
    empleado:[{type: Schema.ObjectId,  ref:('empleado')}]
});




module.exports = mongoose.model('empresa', empresaSchema);